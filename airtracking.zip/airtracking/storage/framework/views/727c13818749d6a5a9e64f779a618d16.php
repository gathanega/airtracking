
<?php if(session('ok')): ?><div class="flash" role="status"><?php echo e(session('ok')); ?></div><?php endif; ?>
<?php /**PATH /home/than/airtracking/resources/views/partials/admin-nav.blade.php ENDPATH**/ ?>